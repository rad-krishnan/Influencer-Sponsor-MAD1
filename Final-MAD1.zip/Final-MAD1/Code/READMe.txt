Change directory in which "run.py" is located, to run the app.

Change Directory to "Code":
cd Code

To run the application:
py run.py 
(or)
python run.py

TO Login:
Sponsor1 : sponsor1@gmail.com - 12345
Influencer1 : influencer1@gmail.com - 12345

Navigate through the respective dashboards from the "NavBar" after successful login.